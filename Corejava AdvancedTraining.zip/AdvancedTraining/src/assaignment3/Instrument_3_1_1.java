package assaignment3;

abstract class Instrument_3_1_1{

	public abstract void Play();
}

class Piano_3_1_4 extends Instrument_3_1_1{

	@Override public void Play(){
		System.out.println("Piano is playing tan tan tan tan");
	}
	}
class Flute_3_1_3 extends Instrument_3_1_1{

	@Override public void Play(){
		System.out.println("Flute is playing toot toot toot toot ");
		}
	}
class Guitar_3_1_2 extends Instrument_3_1_1{
	@Override public void Play()
	{
		System.out.println("Guitar is playing tin tin tin");
		}
	}
class InstrumentMain_3_1_5{

	public static void main(String args[]){

		Instrument_3_1_1 A[] = new Instrument_3_1_1[12];
		for (int iLoop=0; iLoop<12; iLoop++)

		{
			switch (iLoop%3){
			case 0: { A[iLoop] = new Piano_3_1_4(); break; }

			case 1: { A[iLoop] = new Flute_3_1_3(); break; }

			case 2: { A[iLoop] = new Guitar_3_1_2(); break; }
			}
			}



for (int iLoop=0; iLoop<12; iLoop++){


	System.out.println("------------------------------------");
	System.out.println(" object # " + (iLoop+1));

	A[iLoop].Play();

	if (A[iLoop] instanceof Piano_3_1_4) { System.out.println("Piano"); }

	if (A[iLoop] instanceof Flute_3_1_3) { System.out.println("Flute"); }

	if (A[iLoop] instanceof Guitar_3_1_2) { System.out.println("Guitar"); }
	}
}
}
