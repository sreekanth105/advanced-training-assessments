package assaignment7;
class NameNotValidException_7_2_3 extends Exception
{
     public String validname()
     {
          return ("Name is not Valid..Please ReEnter the Name");
     }
}